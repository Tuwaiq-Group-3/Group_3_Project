const initialState= {
    users:{
        id:1,
        name: "user1",
        password: "1",
      },

}


const userReducer= (state=initialState , {type,payload})=>{
     console.log(payload);
    switch (type) {
        case "SET_USERS":
            return {
                state
                // users: payload,
             //   id: (state.users.length-1).id++,
            }
    
        default:
            return state;
    }
   
}


export default userReducer;