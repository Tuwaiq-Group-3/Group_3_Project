import '../App.css';


function Footer() {
  return (
    <div className="div_footer">
<footer className="bg-dark text-center text-white">
  <div className="container p-4 pb-0">
    <section className="mb-4">


    </section>
  </div>

  <div className="text-center p-3" id="footer0" >
  
    © 2021 Copyright - Creator By Group 4
  </div>
</footer>
    </div>
  );
}

export default Footer;
