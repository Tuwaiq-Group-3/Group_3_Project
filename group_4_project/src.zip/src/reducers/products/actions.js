const setList = (list) => {
  return {
    type: "SET_LIST",
    payload: list,
  };
};

export default setList;
